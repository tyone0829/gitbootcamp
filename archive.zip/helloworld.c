#include <stdio.h>

int main(){
int rtn, i;

	rtn=0;
	for(i=0; i<20; i++){
		rtn +=i;
	}

	printf("%d Hello, World3\n", rtn);

	return rtn;
}
